package com.example.mybtchat.data.remote;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.PUT;

public interface ElderlyService {

    @PUT("/users/list/{id}")
    Call<ResponseBody> putElderlyData(@Field("uid") String id);
}